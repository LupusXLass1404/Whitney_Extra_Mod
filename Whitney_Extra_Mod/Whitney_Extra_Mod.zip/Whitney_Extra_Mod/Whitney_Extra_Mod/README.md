## 惠特尼附加模組 Whitney Extra Mod
- 此Mod需要用ModLoader加載。
- 模組非遊戲本體，如果要分享模組相關的截圖／內容，請務必補充說明是模組內容而非原版內容，避免造成不必要的誤會。
- [模組文本整理（Google文件）](https://docs.google.com/document/d/1yQoYOq_Tn64dyLmVLmA3p115v8DQgRyX__M0dL0847I/edit?usp=sharing)：給不想下載模組，但是想看文本的人，當作同人文看就好。
- [Google表單](https://forms.gle/Ht3TkpVFPbZ4Wukp6)：有bug、抓錯字、提供建議。 

## 更新內容
- v1.0.0
  - 增新惠特尼湖邊餵鴨子事件
  - 他會在沒下雨的夜晚出現在湖邊
  - 可以提供爆米花
